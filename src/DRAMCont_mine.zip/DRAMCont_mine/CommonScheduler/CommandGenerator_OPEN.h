
#ifndef COMMANDGENERATOR_OPEN_H
#define COMMANDGENERATOR_OPEN_H

#include "../CommandGenerator.h"

namespace DRAMController
{
	class CommandGenerator_Open: public CommandGenerator
	{
	public:
		CommandGenerator_Open(unsigned int dataBus):CommandGenerator(dataBus)
		{}

		// The command generator should know which command queue to check for schedulability
		bool commandGenerate(Request* request, bool open)
		{
			BusPacketType CAS = RD;
			if(request->requestType == DATA_WRITE) {
				CAS = WR;
			}
			unsigned size = request->requestSize/dataBusSize; 
			unsigned id = request->requestorID;
			unsigned address = request->address;
			unsigned rank = request->rank;
			unsigned bank = request->bank;
			unsigned row = request->row;
			unsigned col = request->col;

			if(!open) {
				commandBuffer.push(new BusPacket(PRE, id, address, 0, row, bank, rank, NULL, 0));
				commandBuffer.push(new BusPacket(ACT, id, address, 0, row, bank, rank, NULL, 0));
			}
			for(unsigned int x = 0; x < size; x++) {
				commandBuffer.push(new BusPacket(CAS, id, address, col+size, row, bank, rank, request->data, 0));
			}
			return true;
		}
	};
}
#endif
