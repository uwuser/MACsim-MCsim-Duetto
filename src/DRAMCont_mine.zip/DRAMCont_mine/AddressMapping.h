/*********************************************************************************
*  Copyright (c) 2015-2016, Danlu Guo
*                             University of Waterloo
*                
*  All rights reserved.
*********************************************************************************/

#ifndef ADDRESS_MAPPING_H
#define ADDRESS_MAPPING_H

#include <vector>
#include <map>
#include <iostream>

#include "Request.h"

namespace DRAMController
{
	class AddressMapping
	{
	public:
		// configTable["AddressMapping"]
		AddressMapping(const std::string& format, const unsigned int (&memTable)[6]);
		void addressMapping(Request* request);
		void addressMapping(unsigned int requestorID, uint64_t physicalAddress, unsigned &newTransactionChan, unsigned &newTransactionRank, unsigned &newTransactionBank, unsigned &newTransactionRow, unsigned &newTransactionColumn, unsigned &newTransactionBankGroup, unsigned &newTransactionSubArray);

	private:
		std::vector<std::pair<unsigned int, unsigned int>> decodeIndex; 

		unsigned log2(unsigned num_value) {
			unsigned logbase2 = 0;
			unsigned value = num_value;
			unsigned orig = value;
			value>>=1;
			while (value>0) {
				value >>= 1;
				logbase2++;
			}
			if ((unsigned)1<<logbase2<orig)logbase2++;
			return logbase2;	
		}
	};
}

#endif
