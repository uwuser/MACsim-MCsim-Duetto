
#ifndef COMMANDSCHEDULER_REZA_H
#define COMMANDSCHEDULER_REZA_H

#include "../../CommandScheduler.h"

namespace DRAMController
{
	class CommandScheduler_Reza: public CommandScheduler
	{
	private:
		// Create the command register	

	public:
		CommandScheduler_Reza(vector<CommandQueue*>& commandQueues, const map<unsigned int, bool>& requestorTable):
			CommandScheduler(commandQueues, requestorTable)
		{}

		~CommandScheduler_Reza()
		{
            // clear buffers
		}

		BusPacket* commandSchedule()
		{
			checkCommand = NULL;
            // index is the memory level in the commandQueue. Since we are using perRequestor base, the queue is size
            // is in channel level which is 0
			for(unsigned int index = 0; index < commandQueue.size(); index++)
			{
				// PerRequestor is enabled and there is some requestors in this memory level
				if(commandQueue[index]->isPerRequestor()) 
				{
					if(commandQueue[index]->getRequestorIndex() > 0)
					{
                        // Iterate each requestor command queue (num is the index for requestors in the commmandQueue, 
                        // not the requestor ID)
						for(unsigned int num=0; num<commandQueue[index]->getRequestorIndex(); num++)
						{
							if(commandQueue[index]->getRequestorSize(num) > 0 )
							{
                                // retrieve the first command on the queue
								checkCommand = commandQueue[index]->getRequestorCommand(num);
                                // Check if the command is ready 
                                if(isReady(checkCommand, index))
                                {
                                    if (checkCommand->busPacketType == BusPacketType::ACT)
                                    {
                                        // Check the request type for the ACT command, the next command should be a CAS
                                        // In this case, the commandQueue[index]->getRequestorSize(num) should be > 1
                                        unsigned int nextCASIndex = 1;
                                        BusPacket* typeChecker = commandQueue[index]->checkRequestorCommand(num, nextCASIndex);
                                        if (typeChecker->busPacketType == BusPacketType::RD)
                                        {
                                            // Do RD scheduling?
                                        }
                                        else if (typeChecker->busPacketType == BusPacketType::WR)
                                        {
                                            // Do WR scheduling
                                        }
                                        else
                                        {
                                            // This should be invalid
                                        }
                                    }
                                    // push into command register. For your command registers, each command must be coupled with a pair of information
                                    // 1. The command pointer
                                    // 2. The index of the requestor in the commandQueue, which is num in this case
                                    //          The index num will be used to remove the actual command from the queue once you send the command out
                                }
							}
						}
					}	
				}
			}

			scheduledCommand = NULL;
			// Schedule the FIFO with CAS blocking
            // Based on your scheduling on the command registers, if you have a scheduled command
            // you need to check if the commmand is issuable. Now assume checkCommand points to the 
            // command in the commmands register checkCommand = command_you_want_to_schedule_and_check_for_issue
            // the index of the command is registerIndex=1.
            unsigned requestorIndex = 1; 
            if(isIssuable(checkCommand)) 
            {
                scheduledCommand = checkCommand;
                // When a command is sent out, it will be removed from the queue
                sendCommand(scheduledCommand, requestorIndex);
            }
            return scheduledCommand;
		}
	};
}
#endif
